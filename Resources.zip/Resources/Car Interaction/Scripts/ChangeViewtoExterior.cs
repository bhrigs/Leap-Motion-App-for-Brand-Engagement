﻿using UnityEngine;
using System.Collections;

public class ChangeViewtoExterior : MonoBehaviour {


	bool inside;

	void Update()
	{
		inside = GameObject.Find ("WholeCar").GetComponent<ChangeViewtoInterior> ().insideCar;
			 }

	void OnTriggerExit(Collider other)
	{
		if(other.name=="Main Camera2" && inside==true)
		{
			GameObject.Find("Main Camera2").transform.parent = GameObject.Find("CameraContainer2").transform;
			GameObject.Find("Main Camera2").transform.localPosition = new Vector3(0, 0, 0);
			GameObject.Find("Main Camera2").transform.localRotation = Quaternion.identity;
			GameObject.Find("Main Camera2").GetComponent<Camera>().fieldOfView=37f;
			GameObject.Find ("WholeCar").GetComponent<ChangeViewtoInterior> ().insideCar = false;
		}
	}
}
