﻿using UnityEngine;
using System.Collections;

public class FRDoorAnimation : MonoBehaviour {

	Animator animator;

	// Use this for initialization
	void Start () {	

		animator = GetComponent<Animator> ();
	}
	

	public void DoorOpenClose(string direction)
	{
		animator.SetTrigger (direction);
	}

}
