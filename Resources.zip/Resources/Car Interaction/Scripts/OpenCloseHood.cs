﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Leap;

//common script to trigger door animations
//each door or trunk will have its own animator clips and controller setup along with it's animation trigger script
public class OpenCloseHood : MonoBehaviour {

	
	bool hoodsOpen, hoodsClose, hoodsOpened, hoodsClosed;

	Controller controller = new Controller();

	void Start()
	{
		hoodsOpen = false;
		hoodsClose = false;
		hoodsOpened = false;
		hoodsClosed = true;

		controller.EnableGesture (Gesture.GestureType.TYPESWIPE);
		controller.Config.SetFloat ("Gesture.Swipe.MinLength", 55500.0f);
		controller.Config.SetFloat ("Gesture.Swipe.MinVelocity", 650f);
		controller.Config.Save ();
	}


	// Update is called once per frame
	void Update () {

		ControlDoors(); //call door control function
	
		if(hoodsOpen == true && hoodsClosed == true)
		{	//call door open animations
			GameObject.Find ("hood").GetComponent<HoodAnimation>().HoodOpenClose("Open");
			
			hoodsClosed = false;

		}	
		else if(hoodsClose == true && hoodsOpened == true)
		{	//call door close animations
			GameObject.Find ("hood").GetComponent<HoodAnimation>().HoodOpenClose("Close");
			
			hoodsOpened=false;

		}			
	}

	void ControlDoors(){//using grab and pitch strengths and open

		if (controller.IsConnected) {
			Frame frame = controller.Frame ();
			
			GestureList gestures = frame.Gestures ();
			for (int i=0; i<gestures.Count; i++) {
				
				Gesture gesture = gestures [i];
				
				if (gesture.Type == Gesture.GestureType.TYPESWIPE && frame.Hands.Count==1) {
					
					SwipeGesture gesSwipe = new SwipeGesture (gesture);
					
					//rotate should work only before a particular line and not around the other buttons to avoid interference
					
					if (gesture.Hands [0].IsLeft && gesture.Hands [1].IsRight) { //rotate vertically with left hand
						
						if (gesSwipe.Direction.y>0 && hoodsOpen == false && hoodsOpened==false) {
							hoodsClosed = true;
							hoodsOpen = true;
							hoodsClose = false;
						} 
						else if (gesSwipe.Direction.y<0 && hoodsClose==false && hoodsClosed==false) {
							hoodsOpened = true;
							hoodsClose = true;
							hoodsOpen = false;
						}
					} 

					else { 

                        //any custom code if you want to
					}
					
				}			
								
			}
		}			

	}
}
