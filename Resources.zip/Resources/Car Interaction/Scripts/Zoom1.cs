﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Leap;

public class Zoom1 : MonoBehaviour {
	
		
	Controller controller = new Controller();
	//based on both hands being present for zooming. If isZooming is not set, one hand can be used for other object interactions like opening doors, etc.
	public bool isZooming = false;
	bool isInterior;

	// Update is called once per frame
	void Update () {

		if (controller.IsConnected) {
			Frame frame = controller.Frame ();

			Leap.Hand objHand1 = frame.Hands[0]; 
			Leap.Hand objHand2 = frame.Hands[1]; 

			isInterior = GameObject.Find ("WholeCar").GetComponent<ChangeViewtoInterior> ().insideCar;

			if (frame.Hands.Count<=1)
			{
				isZooming = false;
			}

			else if (frame.Hands.Count==2)
			{
				if(objHand1.PinchStrength>0.74f && objHand2.PinchStrength>0.74f) //zoom out
				{
					if (isInterior){
						GameObject.Find ("Main Camera2").transform.Translate(0,0,-Time.deltaTime * 0.2f);
					}
					else{
						GameObject.Find ("CameraContainer2").transform.Translate(0,0,-Time.deltaTime * 0.2f);
						
						GameObject.Find ("WholeCar").transform.Translate(0, 0, -Time.deltaTime * 0.05f);
						//if camera is in interior view
					}

					isZooming = true;
				}	
				if(objHand1.PinchStrength<0.6f && objHand2.PinchStrength<0.6f)//zoom in
				{
					if (isInterior){
						GameObject.Find ("Main Camera2").transform.Translate(0,0,Time.deltaTime * 0.2f);
					}
					else{					
						GameObject.Find ("CameraContainer2").transform.Translate(0,0,Time.deltaTime * 0.2f);
						
						GameObject.Find ("WholeCar").transform.Translate(0,0,Time.deltaTime * 0.05f);
						//if camera is in interior view
					}

					isZooming = true;
				}						
				
			}

			
		}
		
	}
}
