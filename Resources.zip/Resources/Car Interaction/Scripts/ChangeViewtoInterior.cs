﻿using UnityEngine;
using System.Collections;

public class ChangeViewtoInterior : MonoBehaviour {


	public bool insideCar = false;


	void OnTriggerEnter(Collider other)
	{
		if(other.name=="Main Camera2" && insideCar==false)
		{
			GameObject.Find("Main Camera2").transform.parent = GameObject.Find("InteriorPlaceholder").transform;
			GameObject.Find("Main Camera2").transform.localPosition = new Vector3(0, 0, 0);
			GameObject.Find("Main Camera2").transform.localRotation = Quaternion.identity;
			GameObject.Find("Main Camera2").GetComponent<Camera>().fieldOfView=60f;
			insideCar = true;
		}
	}

	}
