﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Leap;

public class ToggleViewOption : MonoBehaviour {

	Controller controller = new Controller();
	bool changeView = false;
	bool inside;
	// Use this for initialization
	void Start () {

	}


	void Update()
	{
		if (changeView==true){	
			inside = GameObject.Find ("WholeCar").GetComponent<ChangeViewtoInterior> ().insideCar;
			changeViewNow();
		}

		changeView=false;
	}

	void changeViewNow()
	{
		if (inside == true) {
			GameObject.Find("Main Camera2").transform.parent = GameObject.Find("CameraContainer2").transform;
			GameObject.Find("Main Camera2").transform.localPosition = new Vector3(0, 0, 0);
			GameObject.Find("Main Camera2").transform.localRotation = Quaternion.identity;
			GameObject.Find("Main Camera2").GetComponent<Camera>().fieldOfView=37f;
			GameObject.Find ("WholeCar").GetComponent<ChangeViewtoInterior> ().insideCar = false;
			//change current view icon
			GameObject.Find ("CurrentView").GetComponent<UnityEngine.UI.Image>().sprite = (Sprite)Resources.Load ("IconExterior", typeof(Sprite)); 


		} else if (inside == false) {

			GameObject.Find("Main Camera2").transform.parent = GameObject.Find("InteriorPlaceholder").transform;
			GameObject.Find("Main Camera2").transform.localPosition = new Vector3(0, 0, 0);
			GameObject.Find("Main Camera2").transform.localRotation = Quaternion.identity;
			GameObject.Find("Main Camera2").GetComponent<Camera>().fieldOfView=60f;
			GameObject.Find ("WholeCar").GetComponent<ChangeViewtoInterior> ().insideCar = true;
			//change current view icon
			GameObject.Find ("CurrentView").GetComponent<UnityEngine.UI.Image>().sprite = (Sprite)Resources.Load ("IconInterior", typeof(Sprite)); 
		}


	}

	void OnTriggerEnter(Collider other)
	{
		if (controller.IsConnected) {
			Frame frame = controller.Frame ();	

			if(frame.Hands.Count==1)
			{

			Leap.Hand objHand1 = frame.Hands[0]; 

				if(objHand1.PinchStrength>=0.65f)
				{
	
					if (other.name == "bone1" && other.transform.parent.gameObject.name == "index") {					
					

						changeView=true;					
					
					}
				}
			}
		}
	}

	void OnTriggerExit(Collider other)
	{
		if (other.name == "bone1" && other.transform.parent.gameObject.name == "index") {	
			changeView=false;
		}

	}


}
