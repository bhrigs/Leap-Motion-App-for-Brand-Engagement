﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Leap;

public class RotateCameraInterior : MonoBehaviour {

	bool inside = false;

	Controller controller = new Controller();


	void Start () {
		
		controller.EnableGesture (Gesture.GestureType.TYPECIRCLE);
	}
	
	// Update is called once per frame
	void Update () {
		

		inside = GameObject.Find ("WholeCar").GetComponent<ChangeViewtoInterior> ().insideCar;
		
		if (controller.IsConnected && inside==true) {//for interior view, we will not be rotating car, but the camera. as in interior view camera is attached as a child to the car
			Frame frame = controller.Frame ();
			
			GestureList gestures = frame.Gestures ();
			for (int i=0; i<gestures.Count; i++) {
				
				Gesture gesture = gestures [i];
				
				if (gesture.Type == Gesture.GestureType.TYPECIRCLE && frame.Hands.Count==1) {
					
					CircleGesture gesCircle = new CircleGesture (gesture);
					
					//rotate should work only before a particular line and not around the other buttons to avoid interference
					//in interior view, we will allow for rotation around 2 axii.
					if (gesture.Pointables.Frontmost.TipPosition.z > -30) {
						if (gesture.Hands [0].IsLeft && gesture.Hands [1].IsRight) { //rotate vertically with left hand
							if (gesCircle.Pointable.Direction.AngleTo (gesCircle.Normal) <= System.Math.PI / 2) {
															
								GameObject.Find ("Main Camera2").transform.Rotate (10f * Time.deltaTime, 0, 0);	
														
							} else if (gesCircle.Pointable.Direction.AngleTo (gesCircle.Normal) > System.Math.PI / 2) {
															
								GameObject.Find ("Main Camera2").transform.Rotate (-10f * Time.deltaTime, 0, 0);	
														}
						} else { //rotate horizontally with right hand
							if (gesCircle.Pointable.Direction.AngleTo (gesCircle.Normal) <= System.Math.PI / 2) {

								GameObject.Find ("Main Camera2").transform.Rotate (0, 10f * Time.deltaTime, 0);	
							} else if (gesCircle.Pointable.Direction.AngleTo (gesCircle.Normal) > System.Math.PI / 2) {

								GameObject.Find ("Main Camera2").transform.Rotate (0, -10f * Time.deltaTime, 0);	
							}
						}
					}	
					
				}
				
			}
		}
			
	}
}
