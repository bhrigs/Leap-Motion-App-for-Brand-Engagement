﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Leap;

public class RotateCar1 : MonoBehaviour {
	
//also coded is functionality to not rotate while using the other interaction buttons on the screen.
//so rotate will work only after before a particular Z co-ordinate
	Controller controller = new Controller();
	string clockwiseness;
	bool inside = false;
	public bool isRotating = false; //to use in other classes so as to not interfere with other interactions such as hot spots
	// Use this for initialization
	void Start () {
		
		controller.EnableGesture (Gesture.GestureType.TYPECIRCLE);
	}

// Update is called once per frame
	void Update () {

		isRotating = false;
		inside = GameObject.Find ("WholeCar").GetComponent<ChangeViewtoInterior> ().insideCar;

		if (controller.IsConnected && inside==false) {//for interior view, we will not be rotating car, but the camera. as in interior view camera is attached as a child to the car
			Frame frame = controller.Frame ();

			GestureList gestures = frame.Gestures ();
			for (int i=0; i<gestures.Count; i++) {
				
				Gesture gesture = gestures [i];

				if (gesture.Type == Gesture.GestureType.TYPECIRCLE && frame.Hands.Count==1) {
					
					CircleGesture gesCircle = new CircleGesture (gesture);

					//rotate should work only before a particular line and not around the other buttons to avoid interference
					if (gesture.Pointables.Frontmost.TipPosition.z > -30) {
						if (gesture.Hands [0].IsLeft && gesture.Hands [1].IsRight) { //rotate vertically with left hand
    					//any custom code if you want
						} else { //rotate horizontally with right hand
							if (gesCircle.Pointable.Direction.AngleTo (gesCircle.Normal) <= System.Math.PI / 2) {
								clockwiseness = "clockwise";
								isRotating = true;
								GameObject.Find ("WholeCar").transform.Rotate (0, 0, 10f * Time.deltaTime);	
							} else if (gesCircle.Pointable.Direction.AngleTo (gesCircle.Normal) > System.Math.PI / 2) {
								clockwiseness = "counterclockwise";
								isRotating = true;
								GameObject.Find ("WholeCar").transform.Rotate (0, 0, -10f * Time.deltaTime);	
							}
						}
					}	
				
				}

			}
		}
			
	}
}
