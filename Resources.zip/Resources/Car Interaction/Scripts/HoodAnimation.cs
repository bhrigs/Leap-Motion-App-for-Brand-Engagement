﻿using UnityEngine;
using System.Collections;

public class HoodAnimation : MonoBehaviour {

	Animator animator;

	// Use this for initialization
	void Start () {	

		animator = GetComponent<Animator> ();
	}
	

	public void HoodOpenClose(string direction)
	{
		animator.SetTrigger (direction);
	}

}
