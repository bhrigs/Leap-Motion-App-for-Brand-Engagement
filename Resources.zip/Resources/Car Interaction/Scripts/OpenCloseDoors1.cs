﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Leap;

//common script to trigger door animations
//each door or trunk will have its own animator clips and controller setup along with it's animation trigger script
public class OpenCloseDoors1 : MonoBehaviour {

	//public bool isDoorControlOn = false;
	bool doorsOpen, doorsClose, doorsOpened, doorsClosed;

	Controller controller = new Controller();

	void Start()
	{
		doorsOpen = false;
		doorsClose = false;
		doorsOpened = false;
		doorsClosed = true;

		controller.EnableGesture (Gesture.GestureType.TYPESWIPE);
		controller.Config.SetFloat ("Gesture.Swipe.MinLength", 200);
		controller.Config.SetFloat ("Gesture.Swipe.MinVelocity", 650f);
		controller.Config.Save ();
	}


	// Update is called once per frame
	void Update () {

//		

		
			ControlDoors(); //call door control function
		
	
		if(doorsOpen == true && doorsClosed == true)
		{	//call door open animations
			GameObject.Find ("door_front_right").GetComponent<FRDoorAnimation>().DoorOpenClose("Open");
			GameObject.Find ("door_back_right").GetComponent<BRDoorAnimation>().DoorOpenClose("Open");
			doorsClosed = false;

		}	
		else if(doorsClose == true && doorsOpened == true)
		{	//call door close animations
			GameObject.Find ("door_front_right").GetComponent<FRDoorAnimation>().DoorOpenClose("Close");
			GameObject.Find ("door_back_right").GetComponent<BRDoorAnimation>().DoorOpenClose("Close");
			doorsOpened=false;

		}			
	}

	void ControlDoors(){//using grab and pitch strengths and open

		if (controller.IsConnected) {
			Frame frame = controller.Frame ();
			
			GestureList gestures = frame.Gestures ();
			for (int i=0; i<gestures.Count; i++) {
				
				Gesture gesture = gestures [i];
				
				if (gesture.Type == Gesture.GestureType.TYPESWIPE && frame.Hands.Count==1) {
					
					SwipeGesture gesSwipe = new SwipeGesture (gesture);
					
					//rotate should work only before a particular line and not around the other buttons to avoid interference
					
					if (gesture.Hands [0].IsLeft && gesture.Hands [1].IsRight) { //rotate vertically with left hand
						//include your	custom code if you need to			
					} 

					else if (gesture.Hands [0].IsRight || gesture.Hands [1].IsRight){ //rotate horizontally with right hand
						if (gesSwipe.Direction.z>0 && doorsOpen == false && doorsOpened==false) {
							doorsClosed = true;
							doorsOpen = true;
							doorsClose = false;
						} 
						else if (gesSwipe.Direction.z<0 && doorsClose==false && doorsClosed==false) {
							doorsOpened = true;
							doorsClose = true;
							doorsOpen = false;
						}
					
					}
					
				}			
								
			}
		}			

	}
}
