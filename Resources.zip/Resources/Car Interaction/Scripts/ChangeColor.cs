﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using Leap;

public class ChangeColor : MonoBehaviour {

	Controller controller = new Controller();
	Color[] listColors = new Color[5];
	int colorIndex;
	bool changeColor = false;

	// Use this for initialization
	void Start () {
		listColors [0] = Color.green;
		listColors [1] = Color.cyan;
		listColors [2] = Color.white;
		listColors [3] = Color.red;
		listColors [4] = Color.gray;

		colorIndex = 0;

	}


	void Update()
	{
		if (changeColor==true){
			changeColorNow();
			changeColor=false;
		}

		changeColor=false;
	}

	void changeColorNow()
	{


		if (colorIndex >= 0 && colorIndex < listColors.Length) {
			
			GameObject.Find ("CurrentColor").GetComponent<UnityEngine.UI.Image> ().color = listColors [colorIndex];
			GameObject.Find ("_002_NYPD_car_mat_1").GetComponent<Renderer> ().material.color = listColors [colorIndex];


			colorIndex++;
			
			if (colorIndex == listColors.Length) {
				colorIndex=0;
			}


		} 

	}

	void OnTriggerEnter(Collider other)
	{
		if (controller.IsConnected) {
			Frame frame = controller.Frame ();	

			if(frame.Hands.Count==1)
			{

			Leap.Hand objHand1 = frame.Hands[0]; 

				if(objHand1.PinchStrength>=0.65f)
				{
	
					if (other.name == "bone1" && other.transform.parent.gameObject.name == "index") {					
						//highlight this button
						GameObject.Find ("iconBG").GetComponent<UnityEngine.UI.Image> ().color = Color.white;
						changeColor=true;					
					
					}
				}
			}
		}
	}

	void OnTriggerExit(Collider other)
	{
		if (other.name == "bone1" && other.transform.parent.gameObject.name == "index") {	
			//unhighlight the button - color back to original
			GameObject.Find("iconBG").GetComponent<UnityEngine.UI.Image> ().color = Color.grey;
			changeColor=false;
		}

	}


}
